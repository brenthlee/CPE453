#ifndef ARRAY_H
    #define ARRAY_H

    #define ARR_SIZE 5000

#endif
